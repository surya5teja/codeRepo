package com.jsonValidators;

public  interface JSONBean {

}
