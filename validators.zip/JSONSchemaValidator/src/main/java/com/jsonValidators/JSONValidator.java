package com.jsonValidators;



import java.io.IOException;
import java.io.InputStream;


import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.json.JSONObject;
import org.json.JSONTokener;

import com.fasterxml.jackson.databind.JsonNode;
import com.github.fge.jackson.JsonLoader;
import com.github.fge.jsonschema.core.exceptions.ProcessingException;
import com.github.fge.jsonschema.core.report.ProcessingMessage;
import com.github.fge.jsonschema.core.report.ProcessingReport;
import com.github.fge.jsonschema.main.JsonSchemaFactory;
import com.github.fge.jsonschema.main.JsonValidator;

public class JSONValidator implements
ConstraintValidator<JsonSchemaValidator, Object>{
	
	private String schemaUri;

	public void initialize(JsonSchemaValidator constraintAnnotation) {
		schemaUri=constraintAnnotation.value();
		
		
	}

	public boolean isValid(Object inputjson, ConstraintValidatorContext context) {
		try {
			InputStream inputStream = JSONValidator.class.getClass().getResourceAsStream(schemaUri);
			  JSONObject rawSchema = new JSONObject(new JSONTokener(inputStream));
			  JSONObject returnJson =  new JSONObject();
			  String jsonData=new JSONObject(inputjson).toString();
		      String jsonSchema=rawSchema.toString();
		      JsonNode data;
		     
			
				data = JsonLoader.fromString(jsonData);
			
		      final JsonNode schema = JsonLoader.fromString(jsonSchema);
		      
		      final JsonSchemaFactory factory = JsonSchemaFactory.byDefault();
		      JsonValidator validator = factory.getValidator();
		
		      ProcessingReport report;
			
				report = validator.validate(schema, data);
			 
			      for(ProcessingMessage mess:report)
			      {
			    	returnJson.put(mess.asJson().get("instance").get("pointer").toString(), mess.getMessage());
			      }
			    
			
		}
			catch (ProcessingException e) {
				
				e.printStackTrace();
			}
			catch (IOException e) {
		
				e.printStackTrace();
			}
			return false;
	}
	

}
