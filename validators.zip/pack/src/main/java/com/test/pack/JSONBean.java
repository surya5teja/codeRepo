package com.test.pack;

import com.jsonValidators.JsonSchemaValidator;


public interface JSONBean {

}
