package com.test.pack;

import java.util.Map;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.springframework.stereotype.Component;

public class NameValidator implements
ConstraintValidator<NameValidation, String>{

	@Override
	public void initialize(NameValidation arg0) {
		// TODO Auto-generated method stub
		System.out.println("init");
	}

	@Override
	public boolean isValid(String name, ConstraintValidatorContext arg1) {
		// TODO Auto-generated method stub
		if(name.equalsIgnoreCase("surya"))
		{
			return true;
		}
		return false;
	}

}
