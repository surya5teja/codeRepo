package com.test.pack;

import com.jsonValidators.JsonSchemaValidator;
import com.fasterxml.jackson.annotation.JsonInclude;

import com.jsonValidators.JSONBean;
@JsonSchemaValidator(value="/schema.json")
public class EmployeeBean{
private String id;

private String name;

private long phoneNumber;

private AddressBean address;
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public long getPhoneNumber() {
	return phoneNumber;
}
public void setPhoneNumber(long phoneNumber) {
	this.phoneNumber = phoneNumber;
}
public AddressBean getAddress() {
	return address;
}
public void setAddress(AddressBean address) {
	this.address = address;
}
}
