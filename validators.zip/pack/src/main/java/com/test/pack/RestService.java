package com.test.pack;



import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.Map;

import javax.validation.Valid;

import org.everit.json.schema.Schema;
import org.everit.json.schema.loader.SchemaLoader;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.github.fge.jsonschema.core.exceptions.ProcessingException;
import com.github.fge.jsonschema.core.report.ProcessingMessage;
import com.github.fge.jsonschema.core.report.ProcessingReport;
import com.github.fge.jsonschema.main.JsonSchemaFactory;
import com.github.fge.jsonschema.main.JsonValidator;
import com.jsonValidators.JsonSchemaValidator;
import com.github.fge.jackson.JsonLoader;
import com.fasterxml.jackson.databind.JsonNode;
@RestController 
public class RestService {
	
	/*private final EmployeeBean empBean;

	@Autowired
	public RestService(EmployeeBean empBean)
	{
		this.empBean = empBean;
	}*/
	
	@RequestMapping(
		    value = "/jsontest", 
		    method = RequestMethod.POST) 
	    public String hello(@RequestBody Map<String, Object> inputjson){
		//String name = inputjson.get("name").toString();
		String name = convertMapToPojo(inputjson);
		return name;
	       // return"Hello" +name+ "Welcome to Deloitte";  
	    }  
	
	private static String convertMapToPojo(Map<String,Object> inputMap)
	{
		for (String key : inputMap.keySet()) {
			//System.out.println(inputMap.get(key));
			String val = (inputMap.get(key)!=null && !inputMap.get(key).equals(""))?inputMap.get(key).toString():"default";
		System.out.println(key+"::"+val);
		}
		return "surya";
	}
	
	
	@RequestMapping(
		    value = "/jsonvalidator", 
		    method = RequestMethod.POST) 
	
	    public String jsonValidator( @RequestBody  @Valid EmployeeBean inputjson,BindingResult result, Model m) throws IOException, ProcessingException{
				  //int counter=0;
		
		
		 if(result.hasErrors()) {
             return result.toString();
        }
        m.addAttribute("message", "Invalid name "
          + inputjson.getName());
        return m.toString();
	    } 
	
/*	
	public static void jsonValidator(JSONObject inputjson)
	{
		
		
		JSONObject obj = new JSONObject();
		JSONObject obj1 = new JSONObject();
		obj1.append("a", -5);
		obj1.append("b", 5);
		obj.append("rectangle", obj1);
		try
		{
			InputStream inputStream = RestService.class.getClass().getResourceAsStream("/schema.json");
			 JSONObject rawSchema = new JSONObject(new JSONTokener(inputStream));
			 String st = rawSchema.toString();
			  Schema schema = SchemaLoader.load(rawSchema);
			  schema.validate(new JSONObject(obj)); 
			  
		}
		catch (Exception e) {
			// TODO: handle exception
		e.printStackTrace();
		}
	}*/
	/*public static void main(String[] args) {
		try
		{
			RestService.jsonValidator();
		}
		catch (ValidationException e) {
			  // prints #/rectangle/a: -5.0 is not higher or equal to 0
			  System.out.println(e.getMessage());
			}
	}*/
	@RequestMapping(
		    value = "/jsonvalidators", 
		    method = RequestMethod.POST) 
	 public static String submitForm( @RequestBody @Valid EmployeeBean validateEmp,
		     BindingResult result, Model m) {
		        if(result.hasErrors()) {
		             return "name";
		        }
		        m.addAttribute("message", "Invalid name "
		          + validateEmp.getName());
		        return "name";
		    }   
	    public static void main(String[] arr) throws IOException, ProcessingException{
	    	/*InputStream inputStream = RestService.class.getClass().getResourceAsStream("/schema.json");
			 JSONObject rawSchema = new JSONObject(new JSONTokener(inputStream));
	    	
	    	String jsonData="{\"name\": null,\"id\":\"surya\"}";
	       String jsonSchema=rawSchema.toString();
	       final JsonNode data = JsonLoader.fromString(jsonData);
	       final JsonNode schema = JsonLoader.fromString(jsonSchema);

	       final JsonSchemaFactory factory = JsonSchemaFactory.byDefault();
	       JsonValidator validator = factory.getValidator();

	       ProcessingReport report = validator.validate(schema, data);
	       Iterator iter = report.iterator();
	       while(iter.hasNext())
	       {
	    	   System.out.println(iter.next()); 
	       }*/
	     /* EmployeeBean emp = new EmployeeBean();
	       BindingResult result = null; 
	       Model m = null;
	       emp.setName("teja");
	       submitForm(emp, result, m);*/
	    }


}
