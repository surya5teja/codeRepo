package com.test.pack;

public class TestClass {

}
