package com.test.pack;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.hibernate.validator.spi.valuehandling.ValidatedValueUnwrapper;
import org.json.JSONObject;
import org.json.JSONTokener;

import com.fasterxml.jackson.databind.JsonNode;
import com.github.fge.jackson.JsonLoader;
import com.github.fge.jsonschema.core.exceptions.ProcessingException;
import com.github.fge.jsonschema.core.report.ProcessingMessage;
import com.github.fge.jsonschema.core.report.ProcessingReport;
import com.github.fge.jsonschema.main.JsonSchemaFactory;
import com.github.fge.jsonschema.main.JsonValidator;
import com.jsonValidators.JSONBean;

public class JSONValidator implements
ConstraintValidator<JsonInputValidation, JSONBean>{
	
	private String schemaUri;
	
	@Override
	public void initialize(JsonInputValidation arg0) {
		// TODO Auto-generated method stub
		
		schemaUri=arg0.value();
		System.out.println("init param");
	}

	/*public String isValid(Map<String,Object> inputjson, ConstraintValidatorContext arg1) throws IOException, ProcessingException {
		// TODO Auto-generated method stub
		InputStream inputStream = RestService.class.getClass().getResourceAsStream("/schema.json");
		  JSONObject rawSchema = new JSONObject(new JSONTokener(inputStream));
		  JSONObject returnJson =  new JSONObject();
		  String jsonData=new JSONObject(inputjson).toString();
	      String jsonSchema=rawSchema.toString();
	      final JsonNode data = JsonLoader.fromString(jsonData);
	      final JsonNode schema = JsonLoader.fromString(jsonSchema);
	      
	      final JsonSchemaFactory factory = JsonSchemaFactory.byDefault();
	      JsonValidator validator = factory.getValidator();
	
	      ProcessingReport report = validator.validate(schema, data);
		      for(ProcessingMessage mess:report)
		      {
		    	returnJson.put(mess.asJson().get("instance").get("pointer").toString(), mess.getMessage());
		      }
	    System.out.println("is valid local");
	   return returnJson.toString();
	}*/

	
	@Override
	public boolean isValid(JSONBean inputjson, ConstraintValidatorContext arg1) {
		// TODO Auto-generated method stub
		try {
		//JSONObject json = new JSONObject(inputjson);
		InputStream inputStream = RestService.class.getClass().getResourceAsStream(schemaUri);
		  JSONObject rawSchema = new JSONObject(new JSONTokener(inputStream));
		  JSONObject returnJson =  new JSONObject();
		  String jsonData=new JSONObject(inputjson).toString();
	      String jsonSchema=rawSchema.toString();
	      JsonNode data;
		
			data = JsonLoader.fromString(jsonData);
		
	      final JsonNode schema = JsonLoader.fromString(jsonSchema);
	      
	      final JsonSchemaFactory factory = JsonSchemaFactory.byDefault();
	      JsonValidator validator = factory.getValidator();
	
	      ProcessingReport report;
		
			report = validator.validate(schema, data);
		 
		      for(ProcessingMessage mess:report)
		      {
		    	returnJson.put(mess.asJson().get("instance").get("pointer").toString(), mess.getMessage());
		      }
		    
		//System.out.println("is valid global"+inputjson.getName()+"::"+inputjson.getId());
	}
		catch (ProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
	

}
